<?php

     
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "crunchpress@info.com";
    $email_subject = "New Membership Form Submission";
	$error_message = '';

     

// echo "testing";
// print_r($_POST);

   // validation
    if(empty($_POST['name2']))
    {
     
      echo "Fields are not filled properly";
      die();
    }else if(empty($_POST['email2'])){
       echo "Fields are not filled properly";
        die();
    }else if(empty($_POST['subject2'])){
       echo "Fields are not filled properly";
       die();

    }else if(empty($_POST['comment2'])){
       echo "Fields are not filled properly";
       die();
    }else{     
      
 

    $name = $_POST['name2']; // required
    $email = $_POST['email2']; // required
    $subject = $_POST['subject2']; // required
    $comments = $_POST['comment2'];
  
 
     
    $email_message = '<html>';
    $email_message = '<body>';
    $email_message = '<head>';
    $email_message = '<title>Your Details Are Below</title>';
    $email_message = '</head>';
    $email_message .= '<h1>Your Details Are Below</h1>';
    $email_message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
    $email_message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . strip_tags($_POST['name2']) . "</td></tr>";
    $email_message .= "<tr><td><strong>Email:</strong> </td><td>" . strip_tags($_POST['email2']) . "</td></tr>";
    $email_message .= "<tr><td><strong>Subject:</strong> </td><td>" . strip_tags($_POST['subject2']) . "</td></tr>";
    $email_message .= "<tr><td><strong>Comment:</strong> </td><td>" . strip_tags($_POST['comment2']) . "</td></tr>";
    $email_message .= "</table>";
    $email_message .= "</body></html>"; 



    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: ". $email . "\r\n";
    $headers .= "CC: susan@example.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";


    mail($email_to, $email_subject, $email_message, $headers); 

  }



?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Event Co | Events Management HTML5 Template</title>
<!-- Css Files Start -->
<link href="css/style.css" rel="stylesheet">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/owl.carousel.css" rel="stylesheet">
<link href="css/jquery.bxslider.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link href="css/color.css" rel="stylesheet">
<link href="css/prettyPhoto.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/rtl.css" rel="stylesheet">
<!--Font Family Css Start-->
<link href='https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700italic,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,200,300,300italic,400italic,600,600italic,900,700italic,700,200italic' rel='stylesheet' type='text/css'>
<!-- Css Files End -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>

 <body>
<!--Wrapper Start-->
<div class="cp-wrapper"> 
<!-- Header Start -->
  <header class="cp-header"> 
    <!-- Topbar Start -->
    <div class="cp-topbar">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <ul class="cp-phone-mail">
              <li><i class="fa fa-phone"></i> +440 1234 5678</li>
              <li><i class="fa fa-envelope-o"></i> info@eventco.com</li>
              <li><i class="fa fa-clock-o"></i> Mon - Sat: 07:00 - 19:00</li>
            </ul>
          </div>
          <div class="col-md-6">
            <ul class="cp-top-social">
              <li class="social-links"> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> </li>
              <li> <a class="quote-btn" href="quote.html">Get Quick Quote</a> </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- Nav Bar Start -->
    <div class="cp-nav-logo-bar">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="cp-logo"><a href="index.html"><img src="images/logo.png" alt="Event Co"></a></div>
          </div>
          <div class="col-md-9">
             <nav class="navbar navbar-default"> 
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
              </div>
              
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li class="dropdown"> <a href="index.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Home <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="index.html">Home 1</a></li>
                      <li><a href="index-2.html">Home 2</a></li>
                      <li><a href="index-3.html">Home 3</a></li>
                      <li><a href="index-4.html">Home 4</a></li>
                    </ul>
                  </li>
                  <li><a href="about.html">About</a></li>
                  <li><a href="services.html">Services</a></li>
                  <li class="dropdown"> <a href="events.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Events <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="events.html">Events</a></li>
                      <li><a href="events-listing.html">Events Listing</a></li>
                      <li><a href="events-details.html">Event Details</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="portfolio-1.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Portfolio <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="portfolio-1.html">Portfolio Classic</a></li>
                      <li><a href="portfolio-2.html">Portfolio Modern</a></li>
                      <li><a href="portfolio-3.html">Portfolio Full</a></li>
                      <li><a href="portfolio-4.html">Portfolio Large</a></li>
                      <li><a href="portfolio-5.html">Portfolio Medium</a></li>
                      <li><a href="portfolio-6.html">Portfolio Small</a></li>
                      <li><a href="portfolio-details.html">Portfolio Details</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="blog-post.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Blog <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="blog-post.html">Blog Posts</a></li>
                      <li><a href="blog-medium.html">Blog Medium</a></li>
                      <li><a href="blog-small.html">Blog Small</a></li>
                      <li><a href="blog-details.html">Blog Details</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Features <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li>
                        <a href="#">Shop</a>
                        <ul>
                          <li><a href="shop.html">Shop</a></li>
                          <li><a href="shop-details.html">Shop Details</a></li>
                        </ul>
                      </li>
                      <li>
                         <a href="#">Team</a>
                        <ul>
                          <li><a href="team-v1.html">Team 1</a></li>
                          <li><a href="team-v2.html">Team 2</a></li>
                        </ul>
                      </li>
                      <li><a href="quote.html">Booking Form</a></li>
                      <li><a href="price-tables.html">Price Tables</a></li>
                      <li><a href="testimonials.html">Testimonials</a></li>
                      <li><a href="page-404.html">Page 404</a></li>
                      <li><a href="login.html">Login</a></li>
                      <li><a href="signup.html">Signup</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="contact.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="contact.html">Contact</a></li>
                      <li><a href="contact-v2.html">Contact 2</a></li>
                    </ul>
                  </li>
                </ul>
                <ul class="nav navbar-nav navbar-right cp-search-basket">
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-shopping-basket"></i></a>
                    <ul class="dropdown-menu">
                      <li>
                        <div class="cart-box"> <strong class="title">You have <a href="#">1 item(s)</a> in your cart.</strong>
                          <div class="cart-row">
                            <div class="thumb"><a href="shop.html"><img src="images/cart-pro-img.jpg" alt="img"></a></div>
                            <div class="text-box"> <a href="#" class="close"><i class="fa fa-close"></i></a> <a href="shop.html">BestWedding Flowers Bouquet</a> <strong class="amount">1 x $39.00</strong> </div>
                          </div>
                          <strong class="subtotal">Subtotal: <span>$39.00</span></strong>
                          <div class="btn-row"> <a href="#" class="btn-checkout">Checkout</a> </div>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search"></i></a>
                    <ul class="dropdown-menu">
                      <li>
                        <form class="navbar-form navbar-left" role="search">
                          <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search">
                          </div>
                          <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        </form>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
              <!-- /.navbar-collapse --> 
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- Header End --> 
  
  <!-- Inner Banner Start -->
  <div class="cp-inner-banner">
    <div class="container">
      <div class="cp-inner-banner-outer">
        <h2>Form</h2>
          <!--Breadcrumb Start-->
          <ul class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li class="active">Our Form</li>
          </ul><!--Breadcrumb End-->
        </div>
      </div>
  </div>
  <!-- Inner Banner End --> 
 
 <!--Main Content Start--> 
 <div class="cp-main-content"> 

    <!-- Start of Thank -->
    <section id="content_Wrapper" class="pd-tb60">
      <section class="container container-fluid">
        <div class="row">
          <div class="col-md-12 error-page">
            <div class="holder">
              <h2>Thank You</h2>
              <p>Thank you for your form submission, as soon as we get this we will get back to you shortly.</p>
            </div>
          </div>
        </div>
      </section>
    </section>
    <!-- End of Thank --> 

 <!--Footer Content Start-->
  <footer class="cp-footer">
    <div class="container">
      <!--Footer Top Start-->
      <div class="cp-footer-top pd-tb60">
        <div class="row">
          <div class="col-md-4 col-sm-12">
            <!--Footer Box Start-->
            <div class="cp-ft-box">
              <span class="left">Call <br> us</span>
              <div class="cp-text">
                <i class="fa fa-phone"></i>
                <span>+440 1234 5678</span>
                <span>+440 6589 9874</span>
              </div>
            </div><!--Footer Box End-->
          </div>
          <div class="col-md-4 col-sm-12">
            <!--Footer Box Start-->
            <div class="cp-ft-box">
              <span class="left">Email or Visit</span>
              <div class="cp-text">
                <a href="mailto:">info@eventco.com</a>
                <a href="mailto:">www.eventco.com</a>
              </div>
            </div><!--Footer Box End-->
          </div>
          <div class="col-md-4 col-sm-12">
            <!--Footer Box Start-->
            <div class="cp-ft-box">
              <span class="left">Our Timing</span>
              <div class="cp-text">
                <i class="fa fa-clock-o"></i>
                <span>Mon - Sat</span>
                <span>07:00 - 19:00</span>
                <span class="small">Sunday Closed</span>
              </div>
            </div><!--Footer Box End-->
          </div>
        </div>
      </div><!--Footer Top End-->

      <!--Footer Bottom Start-->
      <div class="cp-footer-bottom pd-b60">
        <div class="row">
          <div class="col-md-3 col-sm-12">
            <!--Widget Start-->
            <div class="widget widget-about">
              <strong class="cp-logo"><a href="index.html"><img src="images/ft-logo.png" alt=""></a></strong>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris hendrerit fringilla ligula, nec congue leo pharetra psum dolor. Maecenas faucibus mollis pinterdum.</p>
            </div><!--Widget End-->
          </div>

          <div class="col-md-3 col-sm-12">
            <!--Widget Start-->
            <div class="widget widget-listed">
              <h3>Our Expert Services</h3>
              <ul>
                <li><a href="#">Birthdays Party</a></li>
                <li><a href="#">Wedding Arrangement</a></li>
                <li><a href="#">Corporate Events</a></li>
                <li><a href="#">Bachelor Parties</a></li>
                <li><a href="#">Proposal Arrange</a></li>
                <li><a href="#">Social Meetings</a></li>
              </ul>
            </div><!--Widget End-->
          </div>

          <div class="col-md-3 col-sm-12">
            <!--Widget Start-->
            <div class="widget widget-listed">
              <h3>Quick Links</h3>
              <ul>
                <li><a href="#">About Eventco</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Booking Online</a></li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Contact</a></li>
              </ul>
            </div><!--Widget End-->
          </div>

          <div class="col-md-3 col-sm-12">
            <!--Widget Start-->
            <div class="widget widget-flickr">
              <h3>Event Photos Gallery</h3>
              <ul>
                <li>
                  <div class="cp-thumb">
                    <a href="#"><img src="images/flickr-img-01.jpg" alt=""></a>
                  </div>
                </li>
                <li>
                  <div class="cp-thumb">
                    <a href="#"><img src="images/flickr-img-02.jpg" alt=""></a>
                  </div>
                </li>
                <li>
                  <div class="cp-thumb">
                    <a href="#"><img src="images/flickr-img-03.jpg" alt=""></a>
                  </div>
                </li>
                <li>
                  <div class="cp-thumb">
                    <a href="#"><img src="images/flickr-img-04.jpg" alt=""></a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div><!--Footer Bottom End-->

      <!--Footer Copyright Start-->
      <div class="cp-copyright-row">
        <div class="row">
          <div class="col-md-6">
            <p>Eventco &copy; 2015, All Rights Reserved, Design & Developed By: <a href="http://crunchpress.com/">CrunchPress</a></p>
          </div>
          <div class="col-md-6">
            <ul class="cp-social-links">
              <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            </ul>
          </div>
        </div>

      </div><!--Footer Copyright End-->

    </div>
  </footer><!--Footer Content End-->

  </div>
</div>
<!--Wrapper End--> 


  <!-- Js Files Start --> 
<script src="js/jquery-1.11.3.min.js"></script> 
<script src="js/owl.carousel.min.js"></script> 
<script src="js/jquery.bxslider.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/migrate.js"></script> 
<script src="js/jquery.prettyPhoto.js"></script> 
<script src="js/jquery.countdown.min.js"></script>
<script src="js/jquery.isotope.js"></script>
<script src="js/animate-form.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
